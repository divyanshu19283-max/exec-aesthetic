import heroPoster from "@/assets/hero-flight.jpg";
import vulcanPoster from "@/assets/closeup-vulcan.jpg";
import rotorPoster from "@/assets/closeup-rotor.jpg";
import sensorPoster from "@/assets/closeup-sensor.jpg";
import framePoster from "@/assets/closeup-frame.jpg";
export const droneData = {
  hero: {
    title: "THE EXECUTIONER",
    subtitle:
      "Next-generation tactical autonomous drone system. 850kW hybrid engine. Vulcan M134 rotary integration.",
    // Hero
    videoPath: "/videos/hero/executioner-tactical-operations.mp4",
    posterPath: heroPoster,
    posterAlt:
      "The Executioner tactical drone in forward flight at golden hour with its Vulcan M134 rotary cannon aimed at a ground target",
  },

  showcase: [
    {
      id: "vulcan",
      eyebrow: "01 / ARMAMENT",
      title: "VULCAN M134",
      subtitle: "Gyro-stabilized rotary platform",
      body: "6,000 rounds per minute, actively counter-torqued by the airframe so recoil never reaches the optics. Fire control is solved in 4ms.",
      // Vulcan
      videoPath: "/videos/hero/closeups/vulcan-cannon.mp4",
      posterPath: vulcanPoster,
      posterAlt:
        "Macro view of the Vulcan M134 six-barrel rotary cannon under a hangar spotlight",
      align: "left" as const,
      stats: [
        { label: "RATE", value: "6000 RPM" },
        { label: "DISPERSION", value: "0.4 MRAD" },
      ],
    },
    {
      id: "rotor",
      eyebrow: "02 / PROPULSION",
      title: "COAXIAL LIFT",
      subtitle: "850kW hybrid drivetrain",
      body: "Twin counter-rotating assemblies machined to a 12µm tolerance. Silent-mode electric loiter for 46 minutes, turbine burst for pursuit.",
      // Rotor (using titanium video)
      videoPath: "/videos/hero/closeups/titanium-frame.mp4",
      posterPath: rotorPoster,
      posterAlt:
        "Close-up of a brushless motor and carbon fibre rotor blade in a dark hangar",
      align: "right" as const,
      stats: [
        { label: "OUTPUT", value: "850 kW" },
        { label: "LOITER", value: "46 MIN" },
      ],
    },
    {
      id: "sensor",
      eyebrow: "03 / PERCEPTION",
      title: "ALL-SEEING",
      subtitle: "Fused multispectral array",
      body: "LWIR, SWIR, and mmWave radar fused on-board. Targets are classified and tracked without a single packet leaving the airframe.",
      // Sensor
      videoPath: "/videos/hero/closeups/sensor-integration.mp4",
      posterPath: sensorPoster,
      posterAlt:
        "Front view of the multispectral EO/IR sensor dome with a blue lens glow",
      align: "left" as const,
      stats: [
        { label: "DETECT", value: "12.4 KM" },
        { label: "TRACKS", value: "128 SIM" },
      ],
    },
    {
      id: "frame",
      eyebrow: "04 / STRUCTURE",
      title: "TITANIUM SPINE",
      subtitle: "Monocoque Ti-6Al-4V",
      body: "A single milled spine carries every load path.",
      // Frame
      videoPath: "/videos/hero/closeups/titanium-frame.mp4",
      posterPath: framePoster,
      posterAlt: "Titanium Frame",
      align: "right" as const,
      stats: [
        { label: "LOAD", value: "9 G" },
        { label: "MASS", value: "212 KG" },
      ],
    },
  ],

  specs: [
    { label: "POWERPLANT", value: "850 kW HYBRID" },
    { label: "TOP SPEED", value: "294 KM/H" },
    { label: "CEILING", value: "6,100 M" },
    { label: "ENDURANCE", value: "4.2 H" },
    { label: "PAYLOAD", value: "184 KG" },
    { label: "DATALINK", value: "AES-256 MESH" },
  ],

  pricing: [
    {
      id: "civilian",
      name: "Research / Civilian",
      price: "$250,000",
      features: [
        "Restricted flight params",
        "Standard support",
        "1-year warranty",
      ],
    },
    {
      id: "government",
      name: "Defense Contractor",
      price: "$850,000",
      features: [
        "Full weapon systems",
        "Military encryption",
        "Priority support",
      ],
      featured: true,
    },
    {
      id: "enterprise",
      name: "Enterprise Security",
      price: "Custom Quote",
      features: [
        "Perimeter defense",
        "Autonomous patrol",
        "Fleet management",
      ],
    },
  ],
};