"use client";

import { useEffect, useState } from "react";
import { motion } from "motion/react";

const links = ["OVERVIEW", "SPECS", "CONTACT"];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1], delay: 0.2 }}
      className="fixed inset-x-0 top-4 z-50 flex justify-center px-4"
    >
      <nav
        className={`flex w-full max-w-4xl items-center justify-between rounded-full px-4 py-2 transition-all duration-500 ${
          scrolled ? "glass-panel" : "border border-transparent"
        }`}
      >
        <a href="#top" className="flex items-center gap-3">
          <span className="flex h-8 w-8 items-center justify-center rounded-full bg-exec-silver font-space text-sm font-bold text-exec-black">
            R
          </span>
          <span className="font-space text-[11px] tracking-[0.3em] text-exec-silver">
            RAJ INDUSTRIES
          </span>
        </a>

        <div className="hidden items-center gap-8 md:flex">
          {links.map((item) => (
            <a
              key={item}
              href={`#${item.toLowerCase()}`}
              className="font-space text-[10px] tracking-[0.25em] text-exec-platinum transition-colors hover:text-exec-white"
            >
              {item}
            </a>
          ))}
        </div>

        <a
          href="#contact"
          className="rounded-full bg-exec-blue px-4 py-1.5 font-space text-[10px] tracking-[0.25em] text-exec-white transition-all hover:brightness-115"
          style={{ boxShadow: "var(--shadow-hud)" }}
        >
          INQUIRE
        </a>
      </nav>
    </motion.header>
  );
}
