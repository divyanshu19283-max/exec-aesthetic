"use client";

type Props = {
  src?: string;
  poster: string;
  posterAlt: string;
  overlayClassName?: string;
};

export function TacticalVideo({
  src,
  poster,
  posterAlt,
}: Props) {
  return (
    <div className="absolute inset-0 h-full w-full">
      {src ? (
        <video
          src={src}
          poster={poster}
          autoPlay
          muted
          loop
          playsInline
          preload="auto"
          className="h-full w-full object-cover"
        />
      ) : (
        <img
          src={poster}
          alt={posterAlt}
          className="h-full w-full object-cover"
        />
      )}

      <div className="absolute inset-0 bg-black/30" />
    </div>
  );
}