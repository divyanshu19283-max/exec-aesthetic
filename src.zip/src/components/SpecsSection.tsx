"use client";

import { motion } from "motion/react";
import { droneData } from "@/data/droneData";

export function SpecsSection() {
  return (
    <section id="specs" className="relative border-t border-border px-6 py-32 md:px-16">
      <div className="pointer-events-none absolute inset-0 grid-overlay opacity-25" />
      <div className="relative mx-auto max-w-6xl">
        <p className="hud-label text-exec-blue">TECHNICAL ENVELOPE</p>
        <h2 className="mt-4 font-rajdhani text-4xl font-bold md:text-6xl">
          <span className="text-titanium">Specifications</span>
        </h2>

        <div className="mt-14 grid grid-cols-1 gap-px overflow-hidden rounded-lg border border-border bg-border sm:grid-cols-2 lg:grid-cols-3">
          {droneData.specs.map((spec, i) => (
            <motion.div
              key={spec.label}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.5 }}
              transition={{ duration: 0.7, delay: i * 0.06 }}
              className="bg-exec-carbon p-8"
            >
              <p className="hud-label">{spec.label}</p>
              <p className="mt-3 font-space text-2xl text-exec-white">{spec.value}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
