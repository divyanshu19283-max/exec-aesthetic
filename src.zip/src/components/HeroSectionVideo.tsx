"use client";

import { motion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";
import { droneData } from "@/data/droneData";
import { TacticalVideo } from "./TacticalVideo";

export function HeroSectionVideo() {
  const ref = useRef<HTMLElement>(null);

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });

  const heroY = useTransform(scrollYProgress, [0, 1], ["0%", "22%"]);
  const heroScale = useTransform(scrollYProgress, [0, 1], [1, 1.15]);
  const heroOpacity = useTransform(scrollYProgress, [0, 0.75], [1, 0]);

  return (
    <section
      ref={ref}
      id="top"
      className="relative min-h-screen bg-black"
    >
      {/* Background */}

     <motion.div
      style={{
        opacity: heroOpacity,
      }}
      className="relative z-20 min-h-screen px-8 md:px-20"
    >
        <TacticalVideo
          src={droneData.hero.videoPath}
          poster={droneData.hero.posterPath}
          posterAlt={droneData.hero.posterAlt}
        />
      </motion.div>

      {/* Dark Overlay */}

      <div className="absolute inset-0 z-10 bg-black/45" />

      {/* Blue Glow */}

      <div className="absolute left-1/2 top-0 h-[900px] w-[900px] -translate-x-1/2 rounded-full bg-cyan-500/10 blur-[180px]" />

      {/* Grid */}

      <div className="absolute inset-0 grid-overlay opacity-20" />

      {/* Scan Line */}

      <motion.div
        animate={{
          y: ["-100%", "120%"],
        }}
        transition={{
          repeat: Infinity,
          duration: 6,
          ease: "linear",
        }}
        className="absolute left-0 right-0 h-40 bg-gradient-to-b from-transparent via-cyan-400/10 to-transparent"
      />

      {/* Content */}

      <motion.div
        style={{
          opacity: heroOpacity,
        }}
        className="relative z-20 h-full px-8 md:px-20"
      >
        {/* HUD */}

        <div className="flex items-center justify-between pt-14">

          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1 }}
            className="glass-panel rounded-full px-5 py-3"
          >
            <p className="font-space text-xs tracking-[0.45em] text-cyan-400">
              ● LIVE FEED
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1 }}
            className="glass-panel rounded-full px-6 py-3"
          >
            <div className="flex items-center gap-4">

              <div>

                <p className="font-bold uppercase text-white">
                  RAJ INDUSTRIES
                </p>

                <p className="font-space text-[11px] tracking-[0.4em] text-gray-400">
                  COMMAND CENTER
                </p>

              </div>

              <div className="h-10 w-10 rounded-full border border-cyan-500 bg-cyan-500/10" />

            </div>
          </motion.div>

        </div>

        {/* Hero */}

        <div className="mt-auto pb-20">

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: .4 }}
            className="font-space text-xs tracking-[0.65em] text-cyan-400"
          >
            AUTONOMOUS TACTICAL PLATFORM
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 80 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{
              duration: 1.2,
            }}
            className="mt-5 leading-[0.82]"
          >

            <span className="block text-[70px] font-black uppercase text-white md:text-[140px]">
              EXECUTIONER
            </span>

            <span className="block bg-gradient-to-r from-cyan-400 via-white to-slate-400 bg-clip-text text-[40px] font-black uppercase text-transparent md:text-[90px]">
              DRONE SYSTEM
            </span>

          </motion.h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
            className="mt-8 max-w-2xl text-lg leading-9 text-gray-300"
          >
            AI-powered autonomous aerial platform engineered for military
            surveillance, tactical reconnaissance and precision mission control.
          </motion.p>

          <div className="mt-12 flex flex-wrap gap-6">

            <motion.a
              whileHover={{ scale: 1.06 }}
              whileTap={{ scale: .97 }}
              href="#specs"
              className="rounded-full bg-cyan-500 px-10 py-5 font-bold text-white"
            >
              EXPLORE SYSTEM
            </motion.a>

            <motion.a
              whileHover={{ scale: 1.06 }}
              href="#gallery"
              className="rounded-full border border-white/20 px-10 py-5 font-bold text-white backdrop-blur-xl"
            >
              WATCH DEMO
            </motion.a>

          </div>

        </div>
        {/* Floating Tactical HUD */}

<motion.div
  initial={{ opacity: 0, scale: 0.8 }}
  animate={{
    opacity: 1,
    scale: 1,
    y: [0, -10, 0],
  }}
  transition={{
    delay: 1.4,
    duration: 1,
    y: {
      repeat: Infinity,
      duration: 4,
      ease: "easeInOut",
    },
  }}
  className="absolute right-10 top-1/2 hidden w-72 -translate-y-1/2 rounded-3xl border border-cyan-500/20 bg-black/40 p-6 backdrop-blur-2xl xl:block"
>

  <div className="mb-4 flex items-center justify-between">

    <span className="font-space text-xs tracking-[0.4em] text-cyan-400">
      AI STATUS
    </span>

    <span className="h-3 w-3 rounded-full bg-green-400 animate-pulse" />

  </div>

  <div className="space-y-4">

    <div>

      <div className="mb-2 flex justify-between">

        <span className="text-sm text-gray-400">
          Target Lock
        </span>

        <span className="text-cyan-300">
          98%
        </span>

      </div>

      <div className="h-2 overflow-hidden rounded-full bg-white/10">

        <motion.div
          initial={{ width: 0 }}
          animate={{ width: "98%" }}
          transition={{
            duration: 2,
          }}
          className="h-full rounded-full bg-cyan-400"
        />

      </div>

    </div>

    <div>

      <div className="mb-2 flex justify-between">

        <span className="text-sm text-gray-400">
          Weapon Sync
        </span>

        <span className="text-cyan-300">
          ONLINE
        </span>

      </div>

      <div className="h-2 overflow-hidden rounded-full bg-white/10">

        <motion.div
          initial={{ width: 0 }}
          animate={{ width: "100%" }}
          transition={{
            duration: 2.5,
          }}
          className="h-full rounded-full bg-cyan-400"
        />

      </div>

    </div>

    <div>

      <div className="mb-2 flex justify-between">

        <span className="text-sm text-gray-400">
          Flight Systems
        </span>

        <span className="text-cyan-300">
          READY
        </span>

      </div>

      <div className="h-2 overflow-hidden rounded-full bg-white/10">

        <motion.div
          initial={{ width: 0 }}
          animate={{ width: "95%" }}
          transition={{
            duration: 3,
          }}
          className="h-full rounded-full bg-cyan-400"
        />

      </div>

    </div>

  </div>

</motion.div>

{/* Rotating Radar */}

<motion.div
  animate={{
    rotate: 360,
  }}
  transition={{
    duration: 14,
    repeat: Infinity,
    ease: "linear",
  }}
  className="absolute left-1/2 top-1/2 hidden h-80 w-80 -translate-x-1/2 -translate-y-1/2 rounded-full border border-cyan-500/10 xl:block"
/>

<motion.div
  animate={{
    rotate: -360,
  }}
  transition={{
    duration: 24,
    repeat: Infinity,
    ease: "linear",
  }}
  className="absolute left-1/2 top-1/2 hidden h-[420px] w-[420px] -translate-x-1/2 -translate-y-1/2 rounded-full border border-white/5 xl:block"
/>

{/* FPS Counter */}

<motion.div
  initial={{ opacity: 0 }}
  animate={{ opacity: 1 }}
  transition={{ delay: 2 }}
  className="absolute bottom-10 left-10 hidden rounded-2xl border border-cyan-500/20 bg-black/40 px-6 py-4 backdrop-blur-xl lg:block"
>

  <p className="font-space text-xs tracking-[0.35em] text-cyan-400">
    SYSTEM
  </p>

  <h3 className="mt-2 text-4xl font-black text-white">
    240 FPS
  </h3>

  <p className="mt-1 text-sm text-gray-400">
    GPU Rendering Active
  </p>

</motion.div>
        {/* Bottom-right telemetry */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.3, duration: 0.8 }}
          className="absolute bottom-14 right-6 hidden w-52 rounded-lg glass-panel p-4 md:block"
        >
          <div className="flex items-baseline justify-between">
            <span className="hud-label">HEADING</span>
            <span className="font-space text-lg text-exec-white">182°</span>
          </div>
          <div className="my-3 h-px w-full bg-border" />
          <div className="flex items-center justify-between">
            <span className="hud-label">TARGET</span>
            <span className="font-space text-[10px] text-exec-blue">LOCKED</span>
          </div>
          <div className="mt-3 h-1 w-full overflow-hidden rounded-full bg-exec-steel">
            <motion.div
              initial={{ width: "12%" }}
              animate={{ width: "84%" }}
              transition={{ delay: 1.6, duration: 1.6, ease: "easeOut" }}
              className="h-full bg-exec-blue"
            />
          </div>
        </motion.div>

        {/* Main title */}
        
      </motion.div>
    </section>
  );
}
