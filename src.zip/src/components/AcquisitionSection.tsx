"use client";

import { motion } from "motion/react";
import { droneData } from "@/data/droneData";

export function AcquisitionSection() {
  return (
    <section id="contact" className="relative border-t border-border px-6 py-32 md:px-16">
      <div className="mx-auto max-w-6xl">
        <div className="text-center">
          <p className="hud-label text-exec-blue">ACQUISITION</p>
          <h2 className="mt-4 font-rajdhani text-4xl font-bold md:text-6xl">
            <span className="text-titanium">Ready to deploy.</span>
          </h2>
          <p className="mx-auto mt-5 max-w-lg text-sm text-exec-platinum">
            Every airframe is built to order under ITAR-controlled process. Configuration is
            confirmed at contract signature.
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-6 lg:grid-cols-3">
          {droneData.pricing.map((tier, i) => (
            <motion.div
              key={tier.id}
              initial={{ opacity: 0, y: 32 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.8, delay: i * 0.1, ease: [0.16, 1, 0.3, 1] }}
              className={`relative flex flex-col rounded-xl glass-panel p-8 ${
                tier.featured ? "ring-1 ring-exec-blue/60" : ""
              }`}
              style={{ boxShadow: tier.featured ? "var(--shadow-hud)" : "var(--shadow-glass)" }}
            >
              {tier.featured && (
                <span className="absolute right-6 top-6 hud-label text-exec-blue">PRIMARY</span>
              )}
              <p className="hud-label">{tier.name}</p>
              <p className="mt-5 font-rajdhani text-4xl font-bold text-exec-white">{tier.price}</p>
              <ul className="mt-8 space-y-3">
                {tier.features.map((f) => (
                  <li key={f} className="flex items-center gap-3 text-sm text-exec-silver/80">
                    <span className="h-1.5 w-1.5 rotate-45 bg-exec-blue" />
                    {f}
                  </li>
                ))}
              </ul>
              <a
                href="mailto:acquisitions@rajindustries.com"
                className={`mt-10 inline-flex items-center justify-center rounded-full px-6 py-3 font-space text-[10px] tracking-[0.28em] transition-all ${
                  tier.featured
                    ? "bg-exec-blue text-exec-white hover:brightness-115"
                    : "border border-exec-silver/25 text-exec-silver hover:border-exec-blue hover:bg-exec-blue/10"
                }`}
              >
                ORDER NOW
              </a>
            </motion.div>
          ))}
        </div>
      </div>

      <footer className="mx-auto mt-28 flex max-w-6xl flex-col items-center justify-between gap-4 border-t border-border pt-8 md:flex-row">
        <span className="font-space text-[10px] tracking-[0.28em] text-exec-platinum">
          RAJ INDUSTRIES · EXECUTIONER PROGRAM
        </span>
        <span className="font-space text-[10px] tracking-[0.28em] text-exec-platinum">
          ITAR CONTROLLED · MMXXVI
        </span>
      </footer>
    </section>
  );
}
