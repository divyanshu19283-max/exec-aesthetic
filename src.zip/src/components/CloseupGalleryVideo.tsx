"use client";

import { motion } from "motion/react";
import { droneData } from "@/data/droneData";
import { TacticalVideo } from "./TacticalVideo";

type Item = (typeof droneData.showcase)[number];

function ShowcaseSection({ item }: { item: Item }) {
  const isLeft = item.align === "left";

  return (
    <section className="relative h-[100svh] w-full overflow-hidden">
      <TacticalVideo
        src={item.videoPath}
        poster={item.posterPath}
        posterAlt={item.posterAlt}
        overlayClassName="from-exec-black via-exec-black/40"
      />

      <div className="pointer-events-none absolute inset-0 grid-overlay opacity-20" />

      <div
        className={`relative z-10 flex h-full items-end px-6 pb-20 md:items-center md:px-16 md:pb-0 ${
          isLeft ? "justify-start" : "justify-end"
        }`}
      >
        <motion.div
          initial={{ opacity: 0, y: 48 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
          className="max-w-xl"
        >
          <p className="hud-label text-exec-blue">{item.eyebrow}</p>
          <h3 className="mt-4 font-rajdhani text-5xl leading-[0.95] font-bold md:text-7xl">
            <span className="text-titanium">{item.title}</span>
          </h3>
          <p className="mt-2 font-space text-[11px] tracking-[0.2em] text-exec-platinum uppercase">
            {item.subtitle}
          </p>
          <p className="mt-6 max-w-lg text-base leading-relaxed text-exec-silver/80">{item.body}</p>

          <div className="mt-8 flex gap-3">
            {item.stats.map((s) => (
              <div key={s.label} className="rounded-lg glass-panel px-5 py-3">
                <p className="hud-label">{s.label}</p>
                <p className="mt-1 font-space text-sm text-exec-white">{s.value}</p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}

export function CloseupGalleryVideo() {
  return (
    <div id="overview" className="relative">
      <div className="relative flex min-h-[70svh] flex-col items-center justify-center px-6 py-32 text-center">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="hud-label"
        >
          ENGINEERING MASTERY
        </motion.p>
        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
          className="mt-6 max-w-4xl font-rajdhani text-4xl leading-[1.05] font-bold md:text-6xl"
        >
          <span className="text-titanium">Forged from titanium.</span>
          <br />
          <span className="text-exec-platinum">Powered by intelligence.</span>
        </motion.h2>
        <div className="mt-14 h-24 w-px dashed-line text-exec-platinum/50" />
      </div>

      {droneData.showcase.map((item) => (
        <ShowcaseSection key={item.id} item={item} />
      ))}
    </div>
  );
}
