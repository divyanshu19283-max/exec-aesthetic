import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { HeroSectionVideo } from "@/components/HeroSectionVideo";
import { CloseupGalleryVideo } from "@/components/CloseupGalleryVideo";
import { SpecsSection } from "@/components/SpecsSection";
import { AcquisitionSection } from "@/components/AcquisitionSection";

const title = "The Executioner — Tactical Drone System | Raj Industries";
const description =
  "The Executioner by Raj Industries: an 850kW hybrid autonomous tactical drone with Vulcan M134 integration, fused multispectral sensing and a titanium monocoque spine.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main className="relative bg-exec-black">
      <Navbar />
      <HeroSectionVideo />
      <CloseupGalleryVideo />
      <SpecsSection />
      <AcquisitionSection />
    </main>
  );
}
